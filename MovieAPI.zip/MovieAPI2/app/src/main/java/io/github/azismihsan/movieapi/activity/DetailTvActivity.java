package io.github.azismihsan.movieapi.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;

import io.github.azismihsan.movieapi.R;
import io.github.azismihsan.movieapi.model.MovieModel;

public class DetailTvActivity extends AppCompatActivity {

    public static final String EXTRA_FILM = "extra_film";
    private static final String URL = "https://image.tmdb.org/t/p/w342";
    private Toolbar toolbar;
    TextView txttitleMovie,txtreleaseDate,txtRating,txtOverview;
    ImageView imgHeader,imgCover;
    ProgressBar progressBar;
    MovieModel movieModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tv);

        initView();
    }
    private void initView(){
        txttitleMovie = findViewById(R.id.txt_title);
        txtreleaseDate = findViewById(R.id.txt_realese);
        txtRating = findViewById(R.id.txt_rating);
        txtOverview = findViewById(R.id.tv_overview);
        imgCover = findViewById(R.id.img_cover);
        imgHeader = findViewById(R.id.bg_background);
        movieModel = getIntent().getParcelableExtra(EXTRA_FILM);
        progressBar = findViewById(R.id.pg_movie);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_black);
        toolbar.setTitle(R.string.app_name);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        CollapsingToolbarLayout collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        collapsingToolbarLayout.setTitle(movieModel.getTitle());
        collapsingToolbarLayout.setCollapsedTitleTextColor(ContextCompat.getColor(getApplicationContext(), R.color.white));
        collapsingToolbarLayout.setExpandedTitleColor(ContextCompat.getColor(getApplicationContext(), R.color.white));

        final Handler handler = new Handler();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                    progressBar.setVisibility(View.GONE);
                } catch (Exception e){
                    e.printStackTrace();
                }
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        txttitleMovie.setText(movieModel.getTitle());
                        txtOverview.setText(movieModel.getOverview());
                        txtreleaseDate.setText(movieModel.getDateRelease());
                        Glide.with(getApplicationContext()).load(URL+movieModel.getPoster()).into(imgCover);
                        Glide.with(getApplicationContext()).load(URL+movieModel.getBgMovie()).into(imgHeader);
                    }
                });
            }
        }).start();
    }
}
