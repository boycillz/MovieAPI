package io.github.azismihsan.movieapi.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.material.tabs.TabLayout;

import io.github.azismihsan.movieapi.R;
import io.github.azismihsan.movieapi.adapter.FragmentAdapter;
import io.github.azismihsan.movieapi.fragment.FragmentFilm;
import io.github.azismihsan.movieapi.fragment.FragmentTv;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initView();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //panggil menu alih bahasa
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.option_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            //action untuk rubah bahasa
            case R.id.menu_bahasa:
                Intent intentBahasa = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(intentBahasa);
                break;
        }
        return true;
    }

    //function untuk inisialisasi view
    private void initView(){
        ViewPager viewPager = findViewById(R.id.view_pager); //panggil viewpager untuk fragment nanti
        setUpViewPager(viewPager); //setting viewpager
        TabLayout tab = findViewById(R.id.tabs);
        tab.setupWithViewPager(viewPager); // setup tab layout dengan viewpager
    }

    private void setUpViewPager(ViewPager viewPager) {
        FragmentAdapter fragmentAdapter = new FragmentAdapter(getSupportFragmentManager());
        fragmentAdapter.addFragment(new FragmentFilm(),getResources().getString(R.string.tab_movie));
        fragmentAdapter.addFragment(new FragmentTv(),getResources().getString(R.string.tab_tv));
        viewPager.setAdapter(fragmentAdapter);
    }
}
