package io.github.azismihsan.movieapi.apihelper;

import io.github.azismihsan.movieapi.model.MovieResponse;
import io.github.azismihsan.movieapi.model.TvResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface BaseApiService {

    @GET("movie/now_plaing")
    Call<MovieResponse> getMovie(
            @Query("api_key") String apiKey,
            @Query("language") String language,
            @Query("page") int page
    );

    @GET("tv/on_the_air")
    Call<TvResponse> getTv(
      @Query("api_key") String apiKey,
      @Query("language") String language,
      @Query("page") int page
    );
}
