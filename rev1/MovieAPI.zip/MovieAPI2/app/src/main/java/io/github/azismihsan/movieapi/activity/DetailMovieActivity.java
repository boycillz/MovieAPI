package io.github.azismihsan.movieapi.activity;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;

import io.github.azismihsan.movieapi.R;
import io.github.azismihsan.movieapi.database.MovieHelper;
import io.github.azismihsan.movieapi.model.MovieModel;

import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_BACKGROUND;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_MOVIE_ID;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_OVERVIEW_MOVIE;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_POSTER;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_RATE;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_RELEASE_DATE;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.COLOUMS_TITLE_MOVIE;
import static io.github.azismihsan.movieapi.database.DatabaseContract.MovieFavorite.CONTENT_URI_MOVIE;

public class DetailMovieActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String EXTRA_MOVIE = "extra_movie";
    private static final String URL = "https://image.tmdb.org/t/p/w342";
    private Toolbar toolbar;
    TextView txttitleMovie,txtreleaseDate,txtRating,txtOverview;
    ImageView imgHeader,imgCover;
    MovieModel movieModel;
    MovieHelper helper;
    Button btnFavorite_,btnUnFavorite_;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        helper = MovieHelper.getInstance(getApplicationContext());
        helper.openConnection();

        initView();
    }

    private void initView(){
        txttitleMovie = findViewById(R.id.txt_title);
        txtreleaseDate = findViewById(R.id.txt_realese);
        txtRating = findViewById(R.id.txt_rating);
        txtOverview = findViewById(R.id.desc_movie);
        imgCover = findViewById(R.id.img_covermovie);
        imgHeader = findViewById(R.id.bg_background);
        movieModel = getIntent().getParcelableExtra(EXTRA_MOVIE);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_black);
        toolbar.setTitle(R.string.app_name);
        setSupportActionBar(toolbar);

        Cursor count = helper.selectMovieFavoriteId(movieModel.getId());
        btnFavorite_ = findViewById(R.id.btn_favorite);
        btnUnFavorite_ = findViewById(R.id.btn_unfavorite);

        if (count.getCount() > 0){
            btnFavorite_.setVisibility(View.GONE);
            btnUnFavorite_.setVisibility(View.VISIBLE);
        }else {
            btnFavorite_.setVisibility(View.VISIBLE);
            btnUnFavorite_.setVisibility(View.GONE);
        }
        btnUnFavorite_.setOnClickListener(this);
        btnFavorite_.setOnClickListener(this);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.collapsing_toolbar);
        collapsingToolbarLayout.setTitle(movieModel.getTitle());
        collapsingToolbarLayout.setCollapsedTitleTextColor
                (ContextCompat.getColor(getApplicationContext(), R.color.white));
        collapsingToolbarLayout.setExpandedTitleColor
                (ContextCompat.getColor(getApplicationContext(), R.color.white));


        txttitleMovie.setText(movieModel.getTitle());
        txtOverview.setText(movieModel.getOverview());
        txtreleaseDate.setText(movieModel.getDateRelease());
        txtRating.setText(String.valueOf(movieModel.getRating()));
        Glide.with(getApplicationContext()).load(URL+movieModel.getPoster()).into(imgCover);
        Glide.with(getApplicationContext()).load(URL+movieModel.getBgMovie()).into(imgHeader);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_favorite:
                ContentValues contentValues = new ContentValues();
                contentValues.put(COLOUMS_MOVIE_ID, movieModel.getId());
                contentValues.put(COLOUMS_TITLE_MOVIE, movieModel.getTitle());
                contentValues.put(COLOUMS_OVERVIEW_MOVIE, movieModel.getOverview());
                contentValues.put(COLOUMS_RATE, movieModel.getRating());
                contentValues.put(COLOUMS_RELEASE_DATE, movieModel.getDateRelease());
                contentValues.put(COLOUMS_POSTER, movieModel.getPoster());
                contentValues.put(COLOUMS_BACKGROUND, movieModel.getBgMovie());

                Uri uri = getContentResolver().insert(CONTENT_URI_MOVIE, contentValues);
                long result = helper.inserMovie(contentValues);
                if (uri != null){
                    Snackbar.make(v, R.string.succes_, Snackbar.LENGTH_SHORT).show();
                    btnUnFavorite_.setVisibility(View.VISIBLE);
                    btnFavorite_.setVisibility(View.GONE);
                    Log.d("Insert Movie", "URL: "+CONTENT_URI_MOVIE);
                }
                break;
            case R.id.btn_unfavorite:
                Uri uri1 = Uri.parse(CONTENT_URI_MOVIE+"/"+movieModel.getId());
                getContentResolver().delete(uri1, null, null);
                Snackbar.make(v, R.string.succes_, Snackbar.LENGTH_SHORT).show();
                btnUnFavorite_.setVisibility(View.GONE);
                btnFavorite_.setVisibility(View.VISIBLE);
                break;
        }
    }
}
