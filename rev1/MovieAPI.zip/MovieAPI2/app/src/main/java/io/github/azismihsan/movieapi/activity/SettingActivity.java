package io.github.azismihsan.movieapi.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import io.github.azismihsan.movieapi.R;
import io.github.azismihsan.movieapi.receiver.ReceiverNotification;
import io.github.azismihsan.movieapi.sharedpref.SharePrefManager;

public class SettingActivity extends AppCompatActivity {

    private SharePrefManager SharePrefM;
    SwitchCompat DailySwitch, ReleaseSwitch;
    ReceiverNotification receiverNotification;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_black);
        toolbar.setTitle(R.string.notification_setting);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        initView();

        DailySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (buttonView.isChecked()){
                    DailySwitch.setChecked(true);
                    SharePrefM.setSharePrefBoolean(SharePrefManager.DAILY_NOTIFICATION, true);
                    String time = "07:30";
                    String message = "Hai, Check our App! Movie Catalogue is missing you";
                    receiverNotification.SettingDailyReminder(SettingActivity.this,
                            ReceiverNotification.TYPE_DAILY_REMINDER_NOTIFICATION, time, message);
                } else {
                    DailySwitch.setChecked(false);
                    SharePrefM.setSharePrefBoolean(SharePrefManager.DAILY_NOTIFICATION, false);
                    receiverNotification.cancelReminder(SettingActivity.this,
                            ReceiverNotification.TYPE_DAILY_REMINDER_NOTIFICATION, ReceiverNotification.ID_DAILY_REMINDER);
                }
            }
        });

        ReleaseSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (buttonView.isChecked()){
                    ReleaseSwitch.setChecked(true);
                    SharePrefM.setSharePrefBoolean(SharePrefManager.RELEASE_NOTIFICATION, true);
                    String time = "08.30";
                    receiverNotification.SettingReleaseReminder(SettingActivity.this,
                            ReceiverNotification.TYPE_RELEASE_REMINDER_NOTIFICATION, time);
                }else {
                    ReleaseSwitch.setChecked(false);
                    SharePrefM.setSharePrefBoolean(SharePrefManager.DAILY_NOTIFICATION, false);
                    receiverNotification.cancelReminder(SettingActivity.this,
                            ReceiverNotification.TYPE_RELEASE_REMINDER_NOTIFICATION, ReceiverNotification.ID_RELEASE_REMINDER);
                }
            }
        });
    }

    private void initView() {
        SharePrefM = new SharePrefManager(this);
        DailySwitch = findViewById(R.id.daily_switch);
        ReleaseSwitch = findViewById(R.id.release_switch);
        receiverNotification = new ReceiverNotification();

        if (!SharePrefM.getStatusDailyReminder()){
            DailySwitch.setChecked(false);
        }else if (SharePrefM.getStatusDailyReminder()){
            DailySwitch.setChecked(true);
        }
        if (!SharePrefM.getStatusReleaseNotification()){
            ReleaseSwitch.setChecked(false);
        } else if (SharePrefM.getStatusReleaseNotification()){
            ReleaseSwitch.setChecked(true);
        }
    }

}
