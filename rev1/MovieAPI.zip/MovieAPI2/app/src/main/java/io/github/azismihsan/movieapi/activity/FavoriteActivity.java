package io.github.azismihsan.movieapi.activity;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import io.github.azismihsan.movieapi.R;
import io.github.azismihsan.movieapi.adapter.FragmentAdapter;
import io.github.azismihsan.movieapi.fragment.FragmentFilmFavorite;
import io.github.azismihsan.movieapi.fragment.FragmentTvFavorite;

public class FavoriteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_black);
        toolbar.setTitle(R.string.favorite_);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        initView();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    private void initView(){
        ViewPager viewPager = findViewById(R.id.view_pager);
        setUpViewPager(viewPager);
        TabLayout tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void setUpViewPager(ViewPager viewPager){
        FragmentAdapter fragmentAdapter = new FragmentAdapter(getSupportFragmentManager());//baru sampai sini
        fragmentAdapter.addFragment(new FragmentFilmFavorite(), getResources().getString(R.string.film_favorite));
        fragmentAdapter.addFragment(new FragmentTvFavorite(), getResources().getString(R.string.tvShow_favorite));
        viewPager.setAdapter(fragmentAdapter);
    }
}
